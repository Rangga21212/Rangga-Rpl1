﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace ApkKasir
{
    public partial class Produk : Form
    {
        public Produk()
        {
            InitializeComponent();
        }
        private void Produk_Load(object sender, EventArgs e)
        {
            string Penjualan = "Data Source=DESKTOP-90USH9S\\sqlexpress01;Initial Catalog=ApkKasir;Integrated Security=True";

            loadData();
            clearData();
        }

        private void loadData()
        {

            string query = "SELECT PenjualanID, TanggalPenjualan, TotalHarga,  FROM KasirPenjualan";

        }
        private void clearData()
        {
            textBox1.Text = "";
            textBox2.Text = "";
           
        }

        private void bBersihkan_Click(object sender, EventArgs e)
        {
            clearData();
            loadData();
        }

        private void Penjualan_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        

        
    }
}

      
