﻿namespace ApkKasir
{
    partial class Penjualan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Penjualan));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.penjualanIDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.masterPenjualanToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.masterPenjualanIDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tanggalPenjualanToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.masterTanggalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.totalHargaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tambahToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.riwayatToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pelangganIDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.penjualanIDToolStripMenuItem,
            this.tanggalPenjualanToolStripMenuItem,
            this.totalHargaToolStripMenuItem,
            this.pelangganIDToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(817, 24);
            this.menuStrip1.TabIndex = 8;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // penjualanIDToolStripMenuItem
            // 
            this.penjualanIDToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.masterPenjualanToolStripMenuItem,
            this.masterPenjualanIDToolStripMenuItem});
            this.penjualanIDToolStripMenuItem.Name = "penjualanIDToolStripMenuItem";
            this.penjualanIDToolStripMenuItem.Size = new System.Drawing.Size(85, 20);
            this.penjualanIDToolStripMenuItem.Text = "Penjualan ID";
            // 
            // masterPenjualanToolStripMenuItem
            // 
            this.masterPenjualanToolStripMenuItem.AccessibleDescription = "MasterPenjualan";
            this.masterPenjualanToolStripMenuItem.Name = "masterPenjualanToolStripMenuItem";
            this.masterPenjualanToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.masterPenjualanToolStripMenuItem.Text = "Master Penjualan";
            // 
            // masterPenjualanIDToolStripMenuItem
            // 
            this.masterPenjualanIDToolStripMenuItem.AccessibleDescription = "MasterPenjualanID";
            this.masterPenjualanIDToolStripMenuItem.Name = "masterPenjualanIDToolStripMenuItem";
            this.masterPenjualanIDToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.masterPenjualanIDToolStripMenuItem.Text = "Master Penjualan ID";
            // 
            // tanggalPenjualanToolStripMenuItem
            // 
            this.tanggalPenjualanToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.masterTanggalToolStripMenuItem});
            this.tanggalPenjualanToolStripMenuItem.Name = "tanggalPenjualanToolStripMenuItem";
            this.tanggalPenjualanToolStripMenuItem.Size = new System.Drawing.Size(115, 20);
            this.tanggalPenjualanToolStripMenuItem.Text = "Tanggal Penjualan";
            // 
            // masterTanggalToolStripMenuItem
            // 
            this.masterTanggalToolStripMenuItem.AccessibleDescription = "MasterTanggal";
            this.masterTanggalToolStripMenuItem.Name = "masterTanggalToolStripMenuItem";
            this.masterTanggalToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.masterTanggalToolStripMenuItem.Text = "Master Tanggal";
            // 
            // totalHargaToolStripMenuItem
            // 
            this.totalHargaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tambahToolStripMenuItem,
            this.riwayatToolStripMenuItem});
            this.totalHargaToolStripMenuItem.Name = "totalHargaToolStripMenuItem";
            this.totalHargaToolStripMenuItem.Size = new System.Drawing.Size(79, 20);
            this.totalHargaToolStripMenuItem.Text = "Total Harga";
            // 
            // tambahToolStripMenuItem
            // 
            this.tambahToolStripMenuItem.AccessibleDescription = "DetailPenjualan";
            this.tambahToolStripMenuItem.Name = "tambahToolStripMenuItem";
            this.tambahToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.tambahToolStripMenuItem.Text = "Tambah";
            // 
            // riwayatToolStripMenuItem
            // 
            this.riwayatToolStripMenuItem.AccessibleDescription = "DetailPenjualan";
            this.riwayatToolStripMenuItem.Name = "riwayatToolStripMenuItem";
            this.riwayatToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.riwayatToolStripMenuItem.Text = "Riwayat";
            // 
            // pelangganIDToolStripMenuItem
            // 
            this.pelangganIDToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.iDToolStripMenuItem});
            this.pelangganIDToolStripMenuItem.Name = "pelangganIDToolStripMenuItem";
            this.pelangganIDToolStripMenuItem.Size = new System.Drawing.Size(89, 20);
            this.pelangganIDToolStripMenuItem.Text = "Pelanggan ID";
            // 
            // iDToolStripMenuItem
            // 
            this.iDToolStripMenuItem.AccessibleDescription = "ID";
            this.iDToolStripMenuItem.Name = "iDToolStripMenuItem";
            this.iDToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.iDToolStripMenuItem.Text = "ID";
            // 
            // Penjualan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.CornflowerBlue;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(817, 440);
            this.Controls.Add(this.menuStrip1);
            this.ForeColor = System.Drawing.Color.Cornsilk;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Penjualan";
            this.Text = "Penjualan";
            this.Load += new System.EventHandler(this.Penjualan_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem penjualanIDToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tanggalPenjualanToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem totalHargaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pelangganIDToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem masterPenjualanToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem masterPenjualanIDToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem masterTanggalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tambahToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem riwayatToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem iDToolStripMenuItem;
    }
}