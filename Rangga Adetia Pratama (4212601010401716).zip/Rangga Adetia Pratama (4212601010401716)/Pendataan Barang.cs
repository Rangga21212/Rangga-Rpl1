﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ApkKasir
{
    public partial class Pendataan_Barang : Form
    {
        public Pendataan_Barang()
        {
            InitializeComponent();
        }

        private void Pendataan_Barang_Load(object sender, EventArgs e)
        {

        }

        private void pendataanBarangToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void stokBarangToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void hargaToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
