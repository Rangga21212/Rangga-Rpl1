﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ApkKasir
{

    public partial class Penjualan : Form
    {
        public Penjualan()
        {
            InitializeComponent();
        }

        private void Penjualan_Load(object sender, EventArgs e)
        {

        }

        private void MasterPenjualan_Click(object sender, EventArgs e)
        {
            Detail_Penjualan newDetail_Penjualan= new Detail_Penjualan();
            this.Hide();
            newDetail_Penjualan.ShowDialog();
            this.Close();
        }
        private void MasterPenjualanID_Click(object sender, EventArgs e)
        {
            Produk newProduk= new Produk();
            this.Hide();
            newProduk.ShowDialog();
            this.Close();
        }
     
        private void PelangganID_Click(object sender, EventArgs e)
        {
            Properties.Settings.Default.Reset();

            Login newLogin = new Login();
            this.Hide();
            newLogin.ShowDialog();
            this.Close();
        }

    }
}
